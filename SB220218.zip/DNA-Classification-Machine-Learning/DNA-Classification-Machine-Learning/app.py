import streamlit as st
import pandas as pd
import numpy as np
import time
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

# Streamlit UI
st.title("DNA Sequence Classification")

# Step 1: Importing the Dataset
st.header("Step 1: Import Dataset")
uploaded_file = st.file_uploader("Upload a CSV file", type=["csv"])
if uploaded_file is not None:
    data = pd.read_csv(uploaded_file)
    st.write("### Dataset Preview:")
    st.write(data.head())
    
    # Step 2: Preprocessing the Dataset
    st.header("Step 2: Data Preprocessing")
    st.write("Cleaning and encoding the DNA sequences...")
    clases = data.iloc[:, 0]  # Assuming first column is Class
    sequences = list(data.iloc[:, -1])  # Assuming last column is Sequence
    
    dic = {}
    for i, seq in enumerate(sequences):
        nucleotides = [char for char in seq if char != '\t']
        nucleotides.append(clases[i])
        dic[i] = nucleotides
    
    df = pd.DataFrame(dic).transpose()
    df.rename(columns={df.columns[-1]: "Class"}, inplace=True)
    
    df_encoded = pd.get_dummies(df)
    df_encoded.drop(columns=['Class_-'], inplace=True, errors='ignore')
    df_encoded.rename(columns={'Class_+': 'Class'}, inplace=True)
    
    st.write("Processed Data Preview:")
    st.write(df_encoded.head())
    
    # Step 3: Training and Testing Classification Algorithms
    st.header("Step 3: Train & Test Models")
    X = df_encoded.drop(['Class'], axis=1)
    y = df_encoded['Class']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    model_choice = st.selectbox("Choose a Classifier", ["Random Forest", "KNN", "SVM", "Naïve Bayes"])
    
    if st.button("Train & Evaluate"):
        st.write("Training the model...")
        progress_bar = st.progress(0)
        time.sleep(1)
        
        if model_choice == "Random Forest":
            from sklearn.ensemble import RandomForestClassifier
            model = RandomForestClassifier()
        elif model_choice == "KNN":
            from sklearn.neighbors import KNeighborsClassifier
            model = KNeighborsClassifier()
        elif model_choice == "SVM":
            from sklearn.svm import SVC
            model = SVC()
        elif model_choice == "Naïve Bayes":
            from sklearn.naive_bayes import GaussianNB
            model = GaussianNB()
        
        for i in range(1, 101):
            time.sleep(0.02)
            progress_bar.progress(i)
        
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        
        # Step 4: Model Evaluation
        st.header("Step 4: Model Evaluation")
        accuracy = accuracy_score(y_test, y_pred)
        st.write(f"### Accuracy: {accuracy:.2f}")
        st.write("Classification Report:")
        st.text(classification_report(y_test, y_pred))
        
        # Step 5: Conclusion
        st.header("Step 5: Conclusion")
        if accuracy > 0.8:
            st.success("The model performs well on the dataset!")
        else:
            st.warning("The model's accuracy is low; consider improving data preprocessing or tuning parameters.")